suppressPackageStartupMessages({
  library(testthat)
  library(officer)
  library(magrittr)
  library(xml2)
})

test_check("officer")
